/* Drop tables */

DROP TABLE order_history;
DROP TABLE order_line;
DROP TABLE order_status;
DROP TABLE cust_order;
DROP TABLE shipping_method;
DROP TABLE customer_address;
DROP TABLE customer;
DROP TABLE address;
DROP TABLE country;
DROP TABLE address_status;
DROP TABLE book_author;
DROP TABLE book;
DROP TABLE book_language;
DROP TABLE publisher;
DROP TABLE author;
